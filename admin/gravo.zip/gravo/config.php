<?php

//$host = "mysql1004.mochahost.com";
//$user = "gravo1_developer";
//$password = "Developer123321";
//$database = "gravo1_gravoDev";
//$conn = mysqli_connect($host, $user, $password, $database);
$host = "localhost";
$user = "root";
$password = "";
$database = "gravo_dev";
$conn = mysqli_connect($host, $user, $password, $database);
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
